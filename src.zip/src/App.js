import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./component/Layout";
import Main from "./component/Main";
import View from "./component/View";
import Edit from "./component/Edit";
import "./app.css"

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Main />}></Route>
          <Route path="/edit" element={<Edit />}></Route>
          <Route path="/view" element={<View />}></Route>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App;
