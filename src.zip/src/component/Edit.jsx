function Edit() {
    return (
        <div>Edit</div>
    );
}

export default Edit;