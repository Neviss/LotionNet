import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";

function Header() {
    return (
        <div>
        <Navbar expand="lg" variant="light" bg="white">
          <Container>
            <div className="d-flex justify-content-start">
              <button  style={{ alignItems: "left" }}>
                <span className="navbar-toggler-icon"></span>
              </button>
            </div>
            <div>
              <div className="boldTop">
                <h1>Lotion</h1>
              </div>
              <div style={{ color: "grey" }}>Like notion, but worse.</div>
            </div>
            <div></div>
          </Container>
        </Navbar>
      </div>
    );
}

export default Header;